package com.impexp.login.controller;

import com.impexp.login.model.Login;
import com.impexp.login.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private LoginService loginService;

    @GetMapping
    public List<Login> listarUsuarios() {
        return loginService.listarUsuarios();
    }

    @PostMapping("/registrar")
    public Login registrarUsuario(
            @RequestBody Login login) {

        return loginService.registrarUsuario(login);
    }

    @PostMapping("/iniciar")
    public boolean iniciarSesion(
            @RequestBody Login login) {

        return loginService.iniciarSesion(
                login.getCorreo(),
                login.getPassword());
    }

    @GetMapping("/{id}")
    public Optional<Login> buscarUsuario(
            @PathVariable Long id) {

        return loginService.buscarUsuario(id);
    }

    @DeleteMapping("/{id}")
    public void eliminarUsuario(
            @PathVariable Long id) {

        loginService.eliminarUsuario(id);
    }
}