package com.impexp.login.service;

import com.impexp.login.model.Login;
import com.impexp.login.repository.LoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LoginService {

    @Autowired
    private LoginRepository loginRepository;

    public List<Login> listarUsuarios() {
        return loginRepository.findAll();
    }

    public Login registrarUsuario(Login login) {
        return loginRepository.save(login);
    }

    public Optional<Login> buscarUsuario(Long id) {
        return loginRepository.findById(id);
    }

    public Optional<Login> buscarPorCorreo(String correo) {
        return loginRepository.findByCorreo(correo);
    }

    public boolean iniciarSesion(String correo, String password) {

        Optional<Login> usuario =
                loginRepository.findByCorreo(correo);

        if(usuario.isPresent()) {

            return usuario.get()
                    .getPassword()
                    .equals(password);
        }

        return false;
    }

    public void eliminarUsuario(Long id) {
        loginRepository.deleteById(id);
    }
}
