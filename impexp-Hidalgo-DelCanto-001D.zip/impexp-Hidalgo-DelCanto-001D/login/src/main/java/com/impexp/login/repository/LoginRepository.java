package com.impexp.login.repository;

import com.impexp.login.model.Login;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LoginRepository extends JpaRepository<Login, Long> {

    Optional<Login> findByCorreo(String correo);
}