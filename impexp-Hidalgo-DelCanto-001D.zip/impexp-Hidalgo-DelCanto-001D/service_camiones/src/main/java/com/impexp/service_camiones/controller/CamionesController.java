package com.impexp.service_camiones.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.impexp.service_camiones.model.Camiones;
import com.impexp.service_camiones.service.CamionesService;

@RestController
@RequestMapping("/camiones")
public class CamionesController {

    @Autowired
    private CamionesService CamionesService;

    @GetMapping
    public List<Camiones> listarCamiones() {
        return CamionesService.listarCamiones();
    }

    @PostMapping
    public Camiones guardarCamion(@RequestBody Camiones camiones) {
        return CamionesService.guardarCamion(camiones);
    }

    @GetMapping("/{id}")
    public Optional<Camiones> buscarCamion(@PathVariable Long id) {
        return CamionesService.buscarCamion(id);
    }

    @DeleteMapping("/{id}")
    public void eliminarCamion(@PathVariable Long id) {
        CamionesService.eliminarCamion(id);
    }
}