package com.impexp.service_camiones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceCamionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceCamionesApplication.class, args);
	}

}
