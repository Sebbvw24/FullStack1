package com.impexp.service_camiones.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.impexp.service_camiones.model.Camiones;
import com.impexp.service_camiones.repository.CamionesRepository;

@Service
public class CamionesService {

    @Autowired
    private CamionesRepository CamionesRepository;

    public List<Camiones> listarCamiones() {
        return CamionesRepository.findAll();
    }

    public Camiones guardarCamion(Camiones camion) {
        return CamionesRepository.save(camion);
    }

    public Optional<Camiones> buscarCamion(Long id) {
        return CamionesRepository.findById(id);
    }

    public void eliminarCamion(Long id) {
        CamionesRepository.deleteById(id);
    }
}