package com.impexp.service_camiones.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.impexp.service_camiones.model.Camiones;

public interface CamionesRepository extends JpaRepository<Camiones, Long> {
}
