package com.impexp.service_camiones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceCamionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
