package com.seguimiento.repository;

import com.seguimiento.model.Seguimiento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SeguimientoRepository extends JpaRepository<Seguimiento, Long> {

    List<Seguimiento> findByAsignacionId(Long asignacionId);
    List<Seguimiento> findByEstadoSeguimiento(String estadoSeguimiento);
    List<Seguimiento> findByUbicacionActual(String ubicacionActual);
}