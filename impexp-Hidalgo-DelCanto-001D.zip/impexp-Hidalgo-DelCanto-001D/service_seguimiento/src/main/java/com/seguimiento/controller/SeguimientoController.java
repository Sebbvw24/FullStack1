package com.seguimiento.controller;

import com.seguimiento.model.Seguimiento;
import com.seguimiento.service.SeguimientoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/seguimientos")
public class SeguimientoController {

    @Autowired
    private SeguimientoService seguimientoService;

    @GetMapping
    public List<Seguimiento> getAll() {
        return seguimientoService.obtenerTodos();
    }

    @GetMapping("/{id}")
    public Seguimiento getById(@PathVariable Long id) {
        return seguimientoService.obtenerPorId(id);
    }

    @PostMapping
    public Seguimiento create(@RequestBody Seguimiento seguimiento) {
        return seguimientoService.registrar(seguimiento);
    }

    @PatchMapping("/{id}/ubicacion")
    public Seguimiento updateUbicacion(
            @PathVariable Long id,
            @RequestParam String ubicacion,
            @RequestParam String estado,
            @RequestParam(required = false) String observacion) {
        return seguimientoService.actualizarUbicacion(id, ubicacion, estado, observacion);
    }

    @GetMapping("/asignacion/{asignacionId}")
    public List<Seguimiento> getByAsignacion(@PathVariable Long asignacionId) {
        return seguimientoService.filtrarPorAsignacion(asignacionId);
    }

    @GetMapping("/estado/{estado}")
    public List<Seguimiento> getByEstado(@PathVariable String estado) {
        return seguimientoService.filtrarPorEstado(estado);
    }

    @GetMapping("/ubicacion/{ubicacion}")
    public List<Seguimiento> getByUbicacion(@PathVariable String ubicacion) {
        return seguimientoService.filtrarPorUbicacion(ubicacion);
    }
}