package com.seguimiento.service;

import com.seguimiento.model.Seguimiento;
import com.seguimiento.repository.SeguimientoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class SeguimientoService {

    @Autowired
    private SeguimientoRepository seguimientoRepository;

    public List<Seguimiento> obtenerTodos() {
        return seguimientoRepository.findAll();
    }

    public Seguimiento obtenerPorId(Long id) {
        return seguimientoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Seguimiento no encontrado con id: " + id));
    }

    public Seguimiento registrar(Seguimiento seguimiento) {
        seguimiento.setFechaActualizacion(LocalDateTime.now());
        return seguimientoRepository.save(seguimiento);
    }

    public Seguimiento actualizarUbicacion(Long id, String ubicacion, String estado, String observacion) {
        Seguimiento s = obtenerPorId(id);
        s.setUbicacionActual(ubicacion);
        s.setEstadoSeguimiento(estado);
        s.setObservacion(observacion);
        s.setFechaActualizacion(LocalDateTime.now());
        return seguimientoRepository.save(s);
    }

    public List<Seguimiento> filtrarPorAsignacion(Long asignacionId) {
        return seguimientoRepository.findByAsignacionId(asignacionId);
    }

    public List<Seguimiento> filtrarPorEstado(String estado) {
        return seguimientoRepository.findByEstadoSeguimiento(estado);
    }

    public List<Seguimiento> filtrarPorUbicacion(String ubicacion) {
        return seguimientoRepository.findByUbicacionActual(ubicacion);
    }
}
