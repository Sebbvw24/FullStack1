package com.seguimiento.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "Seguimiento")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Seguimiento
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long asignacionId;
    private String ubicacionActual;
    private String estadoSeguimiento;
    private String observacion;
    private LocalDateTime fechaActualizacion;
}
