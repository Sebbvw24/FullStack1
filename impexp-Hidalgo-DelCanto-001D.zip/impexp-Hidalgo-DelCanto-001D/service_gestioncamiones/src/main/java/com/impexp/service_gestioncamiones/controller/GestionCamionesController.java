package com.impexp.service_gestioncamiones.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.impexp.service_gestioncamiones.model.GestionCamiones;
import com.impexp.service_gestioncamiones.service.GestionCamionesService;

@RestController
@RequestMapping("/gestioncamiones")
public class GestionCamionesController {

    @Autowired
    private GestionCamionesService gestionCamionService;

    @GetMapping
    public List<GestionCamiones> listarCamiones() {
        return gestionCamionService.listarCamiones();
    }

    @PutMapping("/{id}")
    public GestionCamiones actualizarCamion(
            @PathVariable Long id,
            @RequestBody GestionCamiones camion) {

        return gestionCamionService.actualizarCamion(id, camion);
    }

    @DeleteMapping("/{id}")
    public void eliminarCamion(@PathVariable Long id) {
        gestionCamionService.eliminarCamion(id);
    }
}