package com.impexp.service_gestioncamiones.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impexp.service_gestioncamiones.model.GestionCamiones;
import com.impexp.service_gestioncamiones.repository.GestionCamionesRepository;

@Service
public class GestionCamionesService {

    @Autowired
    private GestionCamionesRepository GestionCamionesRepository;

    public List<GestionCamiones> listarCamiones() {
        return GestionCamionesRepository.findAll();
    }

    public GestionCamiones actualizarCamion(Long id, GestionCamiones camion) {

        Optional<GestionCamiones> camionExistente =
                GestionCamionesRepository.findById(id);

        if (camionExistente.isPresent()) {

            GestionCamiones cam = camionExistente.get();

            cam.setMatricula(camion.getMatricula());
            cam.setPesoMaximo(camion.getPesoMaximo());
            cam.setModelo(camion.getModelo());
            cam.setEstado(camion.getEstado());

            return GestionCamionesRepository.save(cam);
        }

        return null;
    }

    public void eliminarCamion(Long id) {
        GestionCamionesRepository.deleteById(id);
    }
}