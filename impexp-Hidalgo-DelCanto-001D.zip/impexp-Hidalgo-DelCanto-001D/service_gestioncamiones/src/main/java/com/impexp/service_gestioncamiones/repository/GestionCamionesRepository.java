package com.impexp.service_gestioncamiones.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.impexp.service_gestioncamiones.model.GestionCamiones;

public interface GestionCamionesRepository extends JpaRepository<GestionCamiones, Long> {
}