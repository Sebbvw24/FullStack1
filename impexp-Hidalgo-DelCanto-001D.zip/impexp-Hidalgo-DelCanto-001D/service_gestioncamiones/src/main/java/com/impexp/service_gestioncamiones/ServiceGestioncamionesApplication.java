package com.impexp.service_gestioncamiones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceGestioncamionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceGestioncamionesApplication.class, args);
	}

}
