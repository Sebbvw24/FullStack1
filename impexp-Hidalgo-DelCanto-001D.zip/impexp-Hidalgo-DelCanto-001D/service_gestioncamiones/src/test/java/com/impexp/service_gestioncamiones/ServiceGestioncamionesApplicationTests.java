package com.impexp.service_gestioncamiones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceGestioncamionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
