package com.auth.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.auth.model.usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<usuario, Long>
{
    Optional<usuario> findByNombreUsuario(String nombreUsuario);
}