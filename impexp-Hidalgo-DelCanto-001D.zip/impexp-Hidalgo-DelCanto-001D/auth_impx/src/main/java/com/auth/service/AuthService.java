package com.auth.service;

import com.auth.model.Rol;
import com.auth.model.usuario;
import com.auth.repository.UsuarioRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AuthService
{
    private final UsuarioRepository usuarioRepository;
    private final JwtService jwtService;
    private final PasswordEncoder passwordEncoder;

    public AuthService(UsuarioRepository usuarioRepository,
                       JwtService jwtService,
                       PasswordEncoder passwordEncoder)
    {
        this.usuarioRepository = usuarioRepository;
        this.jwtService = jwtService;
        this.passwordEncoder = passwordEncoder;
    }

    public String registrar(usuario usuario)
    {
        usuario.setContrasena(passwordEncoder.encode(usuario.getContrasena()));
        usuarioRepository.save(usuario);
        return "Usuario registrado en el sistema de comercio exterior.";
    }

    public String login(String username, String password)
    {
        System.out.println("Intentando login para: " + username);

        usuario user = usuarioRepository.findByNombreUsuario(username)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        System.out.println("Usuario encontrado en BD: " + user.getNombreUsuario());

        if (passwordEncoder.matches(password, user.getContrasena()))
        {
            List<String> roles = user.getRoles().stream()
                    .map(Rol::getNombreRol)
                    .collect(Collectors.toList());
            return jwtService.generarToken(username, roles);
        }
        throw new RuntimeException("Credenciales inválidas");
    }
}