package com.auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.auth.dto.AuthRequest;
import com.auth.model.usuario;
import com.auth.service.AuthService;

@RestController
@RequestMapping("/auth")
@Tag(name = "Autenticación", description = "Endpoints para registro y login de usuarios del sistema de comercio exterior")
public class AutenticacionController
{
    @Autowired
    private AuthService authService;

    @Operation(summary = "Registrar un nuevo usuario", description = "Guarda el usuario con la contraseña encriptada. Roles: ADMINISTRADOR, OPERADOR, CONDUCTOR, CLIENTE")
    @PostMapping("/registrar")
    public ResponseEntity<String> registrar(@RequestBody usuario usuario)
    {
        return ResponseEntity.ok(authService.registrar(usuario));
    }

    @Operation(summary = "Iniciar sesión", description = "Retorna el Token JWT si las credenciales son válidas")
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody AuthRequest request)
    {
        try
        {
            String token = authService.login(request.getNombreUsuario(), request.getContrasena());
            return ResponseEntity.ok(token);
        }
        catch (RuntimeException e)
        {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        }
    }
}