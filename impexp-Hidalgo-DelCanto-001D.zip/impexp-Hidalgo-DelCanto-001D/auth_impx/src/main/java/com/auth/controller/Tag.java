package com.auth.controller;

public @interface Tag {

    String description();

    String name();

}
