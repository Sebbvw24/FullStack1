package com.auth.controller;

public @interface Operation {

    String summary();

    String description();

}
