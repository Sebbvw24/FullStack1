package com.asignacion.repository;

import com.asignacion.model.Asignacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface Repositoryasignacion extends JpaRepository<Asignacion, Long>
{
    List<Asignacion> findByPlacaCamion(String placaCamion);
    List<Asignacion> findByEstadoAsignacion(String estadoAsignacion);
    List<Asignacion> findByCargaId(Long cargaId);
}