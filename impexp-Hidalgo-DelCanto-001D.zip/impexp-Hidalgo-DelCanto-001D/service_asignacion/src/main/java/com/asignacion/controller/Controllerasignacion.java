package com.asignacion.controller;

import com.asignacion.model.Asignacion;
import com.asignacion.service.AsignacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/asignaciones")
public class Controllerasignacion {

    @Autowired
    private AsignacionService asignacionService;

    @GetMapping
    public ResponseEntity<List<Asignacion>> getAll() {
        return ResponseEntity.ok(asignacionService.obtenerTodas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Asignacion> getById(@PathVariable Long id) {
        return ResponseEntity.ok(asignacionService.obtenerPorId(id));
    }

    @PostMapping
    public ResponseEntity<Asignacion> create(@RequestBody Asignacion asignacion) {
        return ResponseEntity.status(HttpStatus.CREATED).body(asignacionService.registrar(asignacion));
    }

    @PatchMapping("/{id}/estado")
    public ResponseEntity<Asignacion> updateEstado(@PathVariable Long id, @RequestParam String estado) {
        return ResponseEntity.ok(asignacionService.actualizarEstado(id, estado));
    }

    @GetMapping("/placa/{placaCamion}")
    public ResponseEntity<List<Asignacion>> getByPlaca(@PathVariable String placaCamion) {
        return ResponseEntity.ok(asignacionService.filtrarPorPlaca(placaCamion));
    }

    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<Asignacion>> getByEstado(@PathVariable String estado) {
        return ResponseEntity.ok(asignacionService.filtrarPorEstado(estado));
    }

    @GetMapping("/carga/{cargaId}")
    public ResponseEntity<List<Asignacion>> getByCarga(@PathVariable Long cargaId) {
        return ResponseEntity.ok(asignacionService.filtrarPorCarga(cargaId));
    }
}