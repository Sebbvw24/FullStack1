package com.asignacion.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "Asignacion")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Asignacion
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long cargaId;
    private String placaCamion;
    private String conductorNombre;
    private String estadoAsignacion;
    private LocalDateTime fechaAsignacion;
}