package com.asignacion.service;

import com.asignacion.model.Asignacion;
import com.asignacion.repository.Repositoryasignacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Service
public class AsignacionService {

    @Autowired
    private Repositoryasignacion repositoryasignacion;

    private static final List<String> ESTADO_PERMITIDO = Arrays.asList("pendiente", "en tránsito", "entregado", "cancelado");

    public List<Asignacion> obtenerTodas() {
        return repositoryasignacion.findAll();
    }

    public Asignacion obtenerPorId(Long id) {
        return repositoryasignacion.findById(id)
                .orElseThrow(() -> new RuntimeException("Asignacion con id " + id + " no encontrada."));
    }

    public Asignacion registrar(Asignacion asignacion) {
        validar(asignacion);
        asignacion.setEstadoAsignacion("pendiente");
        asignacion.setFechaAsignacion(LocalDateTime.now());
        return repositoryasignacion.save(asignacion);
    }

    public Asignacion actualizarEstado(Long id, String nuevoEstado) {
        if (!ESTADO_PERMITIDO.contains(nuevoEstado)) {
            throw new RuntimeException("Estado inválido. Opciones: " + ESTADO_PERMITIDO);
        }
        Asignacion asignacion = obtenerPorId(id);
        asignacion.setEstadoAsignacion(nuevoEstado);
        return repositoryasignacion.save(asignacion);
    }

    public List<Asignacion> filtrarPorPlaca(String placaCamion) {
        if (placaCamion == null || placaCamion.isBlank()) {
            throw new RuntimeException("La placa del camión es obligatoria para filtrar.");
        }
        return repositoryasignacion.findByPlacaCamion(placaCamion);
    }

    public List<Asignacion> filtrarPorEstado(String estado) {
        if (!ESTADO_PERMITIDO.contains(estado)) {
            throw new RuntimeException("Estado inválido. Opciones: " + ESTADO_PERMITIDO);
        }
        return repositoryasignacion.findByEstadoAsignacion(estado);
    }

    public List<Asignacion> filtrarPorCarga(Long cargaId) {
        if (cargaId == null || cargaId <= 0) {
            throw new RuntimeException("El id de carga debe ser mayor a 0.");
        }
        return repositoryasignacion.findByCargaId(cargaId);
    }

    private void validar(Asignacion asignacion) {
        if (asignacion.getCargaId() == null || asignacion.getCargaId() <= 0)
            throw new RuntimeException("El campo cargaId es obligatorio y debe ser mayor a 0.");

        if (asignacion.getPlacaCamion() == null || asignacion.getPlacaCamion().isBlank())
            throw new RuntimeException("El campo placaCamion es obligatorio.");

        if (asignacion.getConductorNombre() == null || asignacion.getConductorNombre().isBlank())
            throw new RuntimeException("El campo conductorNombre es obligatorio.");
    }
}
